Note :

Application link : prasadbooklist.ccbp.tech

Used linear-gradient colors (#C7C5F4, #776BCC) for better looking hope like.